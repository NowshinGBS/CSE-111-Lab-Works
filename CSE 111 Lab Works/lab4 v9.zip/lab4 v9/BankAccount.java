public class BankAccount
{
 public String Name, AccountId, Address;
  public double Balance;
    public void setName(String n)
    {
      Name=n;
    }
    public String getName()
    {
      return Name;
    }
      public void setAddress(String a)
    {
      Address=a;
    }
     public String getAddress()
    {
      return Address;
    }
    public void setAccountId(String i)
    {
     AccountId=i;
    }
     public String getAccountId()
    {
      return AccountId;
    }
    public void setBalance(double b)
    {
      Balance=b;
    }
     public double getBalance()
    {
      return Balance;
     }
     public double addInterest()
     {
       double ttl= Balance + (Balance)*7/100;
       return ttl;
     }
}
       
