public class Vehicle2010 extends Vehicle
{
  public void moveLowerLeft()
  {
    y--;
    x--;
  }
  public void moveLowerRight()
  {
    y--;
    x++;
  }
  public void moveUpperLeft()
  {
    y++;
    x--;
  }
  public void moveUpperRight()
  {
    y++;
    x++;
  }
  public boolean equals (Vehicle2010 v)
  {
    if(this.x==v.x && this.y==v.y)
      return true;
    else
      return false;
  }
}
    