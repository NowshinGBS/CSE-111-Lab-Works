public class StudentTester
{
    public static void main(String[] args)
    {
      Student s=new Student();
      s.setName("AUNAMIKA");
      System.out.println(s.getName());
         s.setId("12301027");
      System.out.println(s.getId());
         s.setAddress("Tikatuly");
      System.out.println(s.getAddress());
         s.setCgpa(3.5);
      System.out.println(s.getCgpa());
    }
}
      