public class Student
{
 public String Name, Id, Address;
  public double Cgpa;
    public void setName(String n)
    {
      Name=n;
    }
    public String getName()
    {
      return Name;
    }
    public void setId(String i)
    {
      Id=i;
    }
     public String getId()
    {
      return Id;
    }
    public void setAddress(String a)
    {
      Address=a;
    }
     public String getAddress()
    {
      return Address;
    }
    public void setCgpa(double c)
    {
      Cgpa=c;
    }
     public double getCgpa()
    {
      return Cgpa;
    }
  }
