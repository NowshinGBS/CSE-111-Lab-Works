public class BankAccountTester
{
  public static void main(String[] args)
  {
    BankAccount acc1= new BankAccount();
    acc1.setName("AUNAMIKA");
    System.out.println(acc1.getName());
    acc1.setAddress("Tikatuly");
    System.out.println(acc1.getAddress());
    acc1.setAccountId("00987");
    System.out.println(acc1.getAccountId());
    acc1.setBalance(75.2);
    System.out.println(acc1.getBalance());
    acc1.addInterest();
    System.out.println(acc1.addInterest());
  }
}
