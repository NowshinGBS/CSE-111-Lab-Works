import java.util.Scanner;
public class Lab03Task02
{
public static void main (String[] args)
{ 
  Scanner sc=new Scanner(System.in);
  String a=sc.nextLine();
   
  int t;  
  for(t=0; t<a.length(); t++)
  {
 
  System.out.print(a.charAt(t));
}
}
}
