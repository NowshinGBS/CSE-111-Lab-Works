import java.util.Scanner;
public class Lab03Task01
{
public static void main (String[] args)
{ 
  Scanner sc=new Scanner(System.in);
  String a=sc.nextLine();
  char [] ab=a.toCharArray();
  System.out.print(a.length());
}
}