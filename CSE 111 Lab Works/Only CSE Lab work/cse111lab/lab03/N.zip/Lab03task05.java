import java.util.Scanner;
public class Lab03task05
{
public static void main (String[] args)
{
Scanner fr=new Scanner(System.in);
String word1 = fr.next();


String word3= word1  +'\n'+ word1+"==The End==" +'\n'+ word1;
System.out.println(word3);
}
}