import java.util.Scanner;
public class Lab01Task01
{
  public static void main(String [] args)
  {
    Scanner sc=new Scanner(System.in);
    System.out.println("PLease enter a number");
    int num;
    num=sc.nextInt();
    int c;
    
    for(c=1;c<=num;c++)
    {
      System.out.print("*");
    }
  }
}