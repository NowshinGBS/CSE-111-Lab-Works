import java.util.Scanner;
public class ScannerExample3
{
  public static void main(String[] args)
  {
   Scanner fr=new Scanner(System.in);
   System.out.println("Please Enter a Number");
   int x;
   x=fr.nextInt();
   
   System.out.println("Please Enter another Number");
   int y;
   y=fr.nextInt();
   
   int s=x+y;
   int p=x*y;
   int d=x-y;
   System.out.println("The Sum is="+s);
   System.out.println("The Product is="+p);
   System.out.println("The Differenc is="+d);
  }
}