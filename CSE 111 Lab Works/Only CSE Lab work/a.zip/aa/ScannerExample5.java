import java.util.Scanner;
public class ScannerExample5
{
  public static void main(String[] args)
  {
  Scanner fr=new Scanner(System.in);
  System.out .println("Please Enter The Radius");
  double x;
  x=fr.nextDouble();
  
  double c=2*Math.PI*x;
  double a=Math.PI*Math.pow(x,2);
  
  System.out.println("The circumference is="+c);
  System.out.println("The Aera is="+a);
  }
}