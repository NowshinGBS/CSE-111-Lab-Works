import java.util.Scanner;
public class ScannerExample2
{
public static void main(String[] args)
{
Scanner fr=new Scanner(System.in);
System.out.println("Please Enter a Number");
double x;
x=fr.nextDouble();
System.out.println(x);
}
}
  
  