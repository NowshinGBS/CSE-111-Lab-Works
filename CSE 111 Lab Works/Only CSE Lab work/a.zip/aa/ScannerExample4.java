import java.util.Scanner;
public class ScannerExample4
{
  public static void main(String[] args)
  {
  Scanner fr=new Scanner(System.in);
  System.out.println("Please Enter a Number");
  double x;
  x=fr.nextDouble();
  
  System.out.println("Please Enter Another Number");
  double y;
  y=fr.nextDouble();
  
  double s=x+y;
  double p=x*y;
  double d=x-y;
  
  System.out.println("The Sum is="+s);
  System.out.println("The Product is="+p);
  System.out.println("The Differtenc is="+d);
  }
}