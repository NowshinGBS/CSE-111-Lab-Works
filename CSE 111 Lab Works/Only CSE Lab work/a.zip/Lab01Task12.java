import java.util.Scanner;
public class Lab01Task12
{
  public static void main (String [] args)
  {
    Scanner sc=new Scanner(System.in);
    int num=sc.nextInt();
    
    int c;
    for (c=1;c<=num;c++)
    {
      System.out.print(c);
    }
  }
}