import java.util.Scanner;
  public class Lab5Task9b
  {
    public static void main(String[] args)
    {
    Scanner sc=new Scanner(System.in);
    
    int p=-10;
    while(p<21)
    {
    System.out.println(p);
    p=p+5;
    }
    }
  }