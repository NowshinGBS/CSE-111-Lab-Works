import java.util.Scanner;
  public class Lab5Task4
  {
    public static void main(String[] args)
    {
    Scanner sc=new Scanner(System.in);
    
    int p=0;
    while(p<20)
    {
    System.out.println(p);
    p=p+2;
    }
    }
  }