  import java.util.Scanner;
  public class Lab5Task8
  {
    public static void main(String[] args)
    {
    Scanner sc=new Scanner(System.in);
    int p=0;
    while(p<200)
    {
    System.out.println(p);
    p=p+2;
    }
    }
  }