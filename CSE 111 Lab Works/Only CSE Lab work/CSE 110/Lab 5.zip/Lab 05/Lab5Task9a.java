import java.util.Scanner;
  public class Lab5Task9a
  {
    public static void main(String[] args)
    {
    Scanner sc=new Scanner(System.in);
    
    int p=24;
    while(p>-7)
    {
    System.out.println(p);
    p=p-6;
    }
    }
  }