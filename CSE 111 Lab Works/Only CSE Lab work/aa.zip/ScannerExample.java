import java .util.Scanner;
public class ScannerExample
{
  public static void main(String[] args)
  {
    Scanner fr=new Scanner(System.in);
    System.out.println("Please Enter a number");
    int x;
    x=fr.nextInt();
    System.out.println(x);
  }
}